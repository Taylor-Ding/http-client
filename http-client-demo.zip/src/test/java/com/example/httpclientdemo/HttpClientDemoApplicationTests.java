package com.example.httpclientdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
